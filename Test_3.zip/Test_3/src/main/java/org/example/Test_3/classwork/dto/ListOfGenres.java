package org.example.Test_3.classwork.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListOfGenres {

    private  List<Genre> genres = new ArrayList<>(Arrays.asList(new Genre("Rock"),
            new Genre("Pop"),new Genre("Jaz"),new Genre("Rap"),
            new Genre("Classic"),new Genre("Heavy-metal"),new Genre("Electra")));

    private ListOfGenres() {}

    public List<Genre> addNewGen(String name) {
        genres.add(new Genre(name));
        return getGenres();
    }

    public List<Genre> getGenres() {
        return genres;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Genre genre : genres) {
            sb.append(genre).append("\n");
        }
        return sb.toString();
    }

    private static class ListOfGenreHolder {
        private final static ListOfGenres list = new ListOfGenres();
    }

    public static ListOfGenres getInstance() {
        return ListOfGenreHolder.list;
    }
}
