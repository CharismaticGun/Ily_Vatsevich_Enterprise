package org.example.Test_3.classwork.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListOfMusicians {

    private  List<Musician> musicians = new ArrayList<>(Arrays.asList(new Musician("Rammstein"),
            new Musician("Eminem"),new Musician("SOAD"),new Musician("ДДТ")));

    private ListOfMusicians() {

    }

    public List<Musician> addNewMus(String name) {
        musicians.add(new Musician(name));
        return getMusicians();
    }
    public List<Musician> getMusicians() {
        return musicians;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        for (Musician musician : musicians) {
            sb.append(musician).append("\n");
        }
        return sb.toString();
    }

    private static class ListOfMusiciansHolder {
        private final static ListOfMusicians list = new ListOfMusicians();
    }

    public static ListOfMusicians getInstance() {
        return ListOfMusiciansHolder.list;
    }
}
