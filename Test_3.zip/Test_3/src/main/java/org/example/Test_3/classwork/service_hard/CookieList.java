package org.example.Test_3.classwork.service_hard;

import javax.servlet.http.Cookie;
import java.util.ArrayList;
import java.util.List;

public class CookieList {

    private final List<Cookie> cookies = new ArrayList<>();

    public List<Cookie> getCookies() {
        return cookies;
    }


}
