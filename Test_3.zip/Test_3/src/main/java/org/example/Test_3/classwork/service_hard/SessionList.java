package org.example.Test_3.classwork.service_hard;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

public class SessionList {

    private final List<HttpSession> sessions = new ArrayList<>();

    public List<HttpSession> getSessions() {
        return sessions;
    }
}
