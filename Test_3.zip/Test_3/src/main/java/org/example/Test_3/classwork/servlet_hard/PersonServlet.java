package org.example.Test_3.classwork.servlet_hard;

import org.example.Test_3.classwork.dto.Person;
import org.example.Test_3.classwork.service_hard.CookieList;
import org.example.Test_3.classwork.service_hard.SessionList;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Predicate;

@WebServlet(name = "PersonServlet", value = "/person")
public class PersonServlet extends HttpServlet {

    private static int counter = 1;

    private final int id = counter++;

    private final CookieList cookieList;

    private final SessionList sessionList;

    private final String HEADER_COOKIE = "COOKIE";

    private final String HEADER_SESSION = "SESSION";

    public PersonServlet() {
        this.cookieList = new CookieList();
        this.sessionList = new SessionList();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        response.setContentType("text/html; charset=UTF-8");

        PrintWriter writer = response.getWriter();

        String name = "user1";

        String encode = URLEncoder.encode(";", StandardCharsets.UTF_8);

        Enumeration<String> headerNames = request.getHeaderNames();
        Iterator<String> stringIterator = headerNames.asIterator();
        while (stringIterator.hasNext()) {
            String next = headerNames.asIterator().next();
            if (next.equalsIgnoreCase(HEADER_SESSION)) {
                HttpSession session = request.getSession();
                writer.write("<h1>" + session.getAttribute("user") + "</h1>");
                break;
            } else if (next.equalsIgnoreCase(HEADER_COOKIE)) {
                Cookie[] cookies = request.getCookies();
                for (Cookie cookie : cookies) {
                    if (cookie.getName().equalsIgnoreCase(name)) {
                        String[] split = cookie.getValue().split(encode);
                        for (String s : split) {
                            writer.write("<p>" + s + "</p></br>");
                        }
                        break;
                    }
                }
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String firstName = req.getParameter("firstName");

        String lastName = req.getParameter("lastName");

        int age = Integer.parseInt(req.getParameter("age"));

        Enumeration<String> headerNames = req.getHeaderNames();

        resp.setContentType("text/html;charset=UTF-8");

        PrintWriter writer = resp.getWriter();

        Iterator<String> stringIterator = headerNames.asIterator();

        String encode = URLEncoder.encode(";", StandardCharsets.UTF_8);

        while (stringIterator.hasNext()) {
            String next = stringIterator.next();
            if (next.equalsIgnoreCase(HEADER_SESSION)) {
                req.getSession().setAttribute("user",
                        new Person(firstName,lastName,age));
                break;
            } else if (next.equalsIgnoreCase(HEADER_COOKIE)) {
                Cookie cookie = new Cookie("user1",firstName+encode+lastName+encode+age);
                cookie.setMaxAge(Math.toIntExact(TimeUnit.DAYS.toSeconds(1)));
                resp.addCookie(cookie);
                break;
            }
        }
    }
}
