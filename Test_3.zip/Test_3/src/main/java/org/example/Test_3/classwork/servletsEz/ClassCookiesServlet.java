package org.example.Test_3.classwork.servletsEz;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.TimeUnit;

@WebServlet(name = "ClassServlet", value = "/cookies")
public class ClassCookiesServlet extends HttpServlet {

    private  Cookie myCookieFirst;

    private  Cookie myCookieLast ;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String firstName = request.getParameter("firstName");

        String lastName = request.getParameter("lastName");

        response.setContentType("text/html; charset=UTF-8");

        PrintWriter writer = response.getWriter();

        if (firstName!=null&&lastName!=null) {

            myCookieFirst = new Cookie("firstName",firstName);

            myCookieLast = new Cookie("lastName",lastName);

            myCookieFirst.setMaxAge(Math.toIntExact(TimeUnit.DAYS.toSeconds(1)));

            myCookieLast.setMaxAge(Math.toIntExact(TimeUnit.DAYS.toSeconds(1)));

            response.addCookie(myCookieFirst);

            response.addCookie(myCookieLast);

            writer.write("<h1>Hello " + firstName + " " + lastName + "</h1>");

        } else if (myCookieFirst.getValue()!=null&&myCookieLast.getValue()!=null) {
            writer.write("<h1>Hello " + myCookieFirst.getValue() + " " + myCookieLast.getValue() + "</h1>");
        } else {
            throw new IllegalArgumentException("Параметров нет!");
        }
    }
}
