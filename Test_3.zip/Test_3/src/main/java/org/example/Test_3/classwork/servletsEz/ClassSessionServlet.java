package org.example.Test_3.classwork.servletsEz;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ClassSessionServlet", value = "/session")
public class ClassSessionServlet extends HttpServlet {

    private HttpSession session;

    private HttpSession session1;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String firstName = request.getParameter("firstName");

        String lastName  = request.getParameter("lastName");

        response.setContentType("text/html; charset=UTF-8");

        PrintWriter writer = response.getWriter();

        if (firstName!=null&&lastName!=null) {

            session = request.getSession();

            session1 = request.getSession();

            session.setAttribute("firstName",firstName);

            session1.setAttribute("lastName",lastName);

            writer.write("<h1>Hello " + firstName + " " + lastName + "</h1>");

        } else if (session!=null&&session1!=null) {
            writer.write("<h1>Hello " + session.getAttribute("firstName") + " "
                    + session1.getAttribute("lastName") + "</h1>");
        } else {
            throw new IllegalArgumentException("Параметров нет!");
        }
    }
}
