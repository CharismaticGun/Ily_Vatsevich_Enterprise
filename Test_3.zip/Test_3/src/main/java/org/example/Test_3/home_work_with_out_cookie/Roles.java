package org.example.Test_3.home_work_with_out_cookie;

public enum Roles {
    ADMIN,
    USER
}
