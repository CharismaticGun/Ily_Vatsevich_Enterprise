package org.example.Test_3.home_work_with_out_cookie.api.service;

import org.example.Test_3.home_work_with_out_cookie.dto.Message;
import org.example.Test_3.home_work_with_out_cookie.dto.User;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class MessageControl {

    MessageStorage ms = MessageStorage.getInstance();

    public boolean sendMessage(HttpServletRequest request, String login, String messageText) {

        User attribute = (User) request.getSession().getAttribute("user");

        if (!attribute.getLogin().equals(login)) {
            ms.getMessages().add(new Message(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS),
                    attribute.getLogin(),
                    login,
                    messageText));
            return true;
        }
        return false;
    }

    public List<Message> getMessage(HttpServletRequest request) {

        User attribute = (User) request.getSession().getAttribute("user");

        List<Message> messages = new ArrayList<>();

        for (Message message : ms.getMessages()) {
            if (message.getToWho().equals(attribute.getLogin())) {
                messages.add(message);
            }
        }
        return messages;
    }

}
