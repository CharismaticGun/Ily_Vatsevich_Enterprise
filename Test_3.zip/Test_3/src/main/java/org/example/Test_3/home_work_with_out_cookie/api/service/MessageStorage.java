package org.example.Test_3.home_work_with_out_cookie.api.service;

import org.example.Test_3.home_work_with_out_cookie.dto.Message;
import java.util.ArrayList;
import java.util.List;

public class MessageStorage {
    private final List<Message> messages;
    private MessageStorage(List<Message> messages) {
        this.messages = messages;
    }
    private static class MessageStorageHandler {
        private static final MessageStorage storage = new MessageStorage(new ArrayList<>());
    }

    public static MessageStorage getInstance() {
        return MessageStorageHandler.storage;
    }

    public List<Message> getMessages() {
        return messages;
    }
}
