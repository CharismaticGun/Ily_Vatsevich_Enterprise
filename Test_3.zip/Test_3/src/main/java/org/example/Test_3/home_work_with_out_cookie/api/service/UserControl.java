package org.example.Test_3.home_work_with_out_cookie.api.service;

import org.example.Test_3.home_work_with_out_cookie.dto.User;

import java.util.Arrays;

public class UserControl {

    UserStorage storage = UserStorage.getInstance();

    public User userLogIn(String login,String password) {
        for (User user : storage.getUsers()) {
            if (Arrays.equals(user.getPassword(), password.toCharArray())
                    && user.getLogin().equals(login)) {
                return user;
            }
        }
        throw new IllegalArgumentException("Логин или пароль неверные");
    }
}
