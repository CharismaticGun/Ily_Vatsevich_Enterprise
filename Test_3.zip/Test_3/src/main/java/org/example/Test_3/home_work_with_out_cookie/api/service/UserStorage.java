package org.example.Test_3.home_work_with_out_cookie.api.service;

import org.example.Test_3.home_work_with_out_cookie.Roles;
import org.example.Test_3.home_work_with_out_cookie.dto.User;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UserStorage {
    private final List<User> users;
    private UserStorage(List<User> users) {
        this.users = users;
    }

    private static class UserStorageHandler {
        private static final UserStorage userStorage = new UserStorage(new ArrayList<>());
    }

    public static UserStorage getInstance() {
        return UserStorageHandler.userStorage;
    }

    public boolean userRegistration(String login,String password,String fullName,String dateOfBirth) {
        if (users.isEmpty()) {
            users.add(new User("admin",
                    "admin".toCharArray(),
                    "Ivan Jovanovich Ivanov",
                    "18.09.1990",
                    LocalDate.now(),
                    Roles.ADMIN.name()));
        }

        boolean b = getUsers().stream().noneMatch(user -> user.getLogin().equals(login));

        if (b) {
            users.add(new User(login,
                    password.toCharArray(),
                    fullName,
                    dateOfBirth,
                    LocalDate.now(),
                    Roles.USER.name()));
            return true;
        }
        return false;
    }
    public List<User> getUsers() {
        return users;
    }
}
