package org.example.Test_3.home_work_with_out_cookie.api.servlets;

import org.example.Test_3.home_work_with_out_cookie.dto.User;
import org.example.Test_3.home_work_with_out_cookie.api.service.UserControl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ServletUserLogin", value = "/api/login")
public class ServletUserLogin extends HttpServlet {

    UserControl us = new UserControl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String login = request.getParameter("login");

        String password = request.getParameter("password");

        User user = us.userLogIn(login, password);

        request.getSession().setAttribute("user",user);

    }
}
