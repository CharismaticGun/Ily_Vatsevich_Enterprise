package org.example.Test_3.home_work_with_out_cookie.api.servlets;

import org.example.Test_3.home_work_with_out_cookie.api.service.MessageControl;
import org.example.Test_3.home_work_with_out_cookie.dto.Message;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "ServletUserMessaging", value = "/api/message")
public class ServletUserMessaging extends HttpServlet {

    MessageControl mc = new MessageControl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        List<Message> message = mc.getMessage(request);

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter writer = response.getWriter();

        for (Message message1 : message) {
            writer.write("<p>" + "Время отправки: " + message1.getTimeOfSend() +
                    " От кого: " + message1.getFromWho() + " текст: "+ message1.getTextOfMessage() + "</br></p>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String login = request.getParameter("login");

        String messageText = request.getParameter("messageText");

        boolean b = mc.sendMessage(request, login, messageText);

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter writer = response.getWriter();

        if (b) {
            writer.write("Message sent!");
        } else {
            writer.write("You can't send a message to yourself");
        }
    }
}
