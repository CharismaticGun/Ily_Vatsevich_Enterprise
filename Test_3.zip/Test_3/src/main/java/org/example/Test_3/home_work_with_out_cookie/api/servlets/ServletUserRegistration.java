package org.example.Test_3.home_work_with_out_cookie.api.servlets;

import org.example.Test_3.home_work_with_out_cookie.dto.User;
import org.example.Test_3.home_work_with_out_cookie.api.service.UserStorage;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

@WebServlet(name = "ServletUserRegistration", value = "/api/user")
public class ServletUserRegistration extends HttpServlet {

    private UserStorage storage = UserStorage.getInstance();

    private static int counter = 0;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String login = request.getParameter("login");

        String password = request.getParameter("password");

        String fullName = request.getParameter("fullName");

        String dateOfBirth = request.getParameter("dateOfBirth");

        boolean checkRegistration = storage.userRegistration(login, password, fullName, dateOfBirth);

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter writer = response.getWriter();

        Cookie[] cookies = request.getCookies();

        if (checkRegistration) {
            for (User user : storage.getUsers()) {
                if (cookies!=null) {
                    boolean checkCookie = Arrays.stream(cookies).noneMatch(cookie -> cookie.getValue().equals(user.getLogin()));
                    if (checkCookie) {
                        response.addCookie(new Cookie("user"+(++counter),user.getLogin()));
                    }
                } else {
                    response.addCookie(new Cookie("user"+(++counter),user.getLogin()));
                    writer.write("Регистрация прошла успешно");
                }
            }
        } else {
            writer.write("Пользователь с таким логином уже есть");
        }
    }
}
