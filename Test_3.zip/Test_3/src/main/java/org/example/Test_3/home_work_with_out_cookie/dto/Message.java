package org.example.Test_3.home_work_with_out_cookie.dto;

import java.time.LocalDateTime;

public class Message {

    private LocalDateTime timeOfSend;

    private String fromWho;

    private String toWho;

    private String textOfMessage;

    public Message() {}

    public Message(LocalDateTime timeOfSend, String fromWho, String toWho, String textOfMessage) {
        this.timeOfSend = timeOfSend;
        this.fromWho = fromWho;
        this.toWho = toWho;
        this.textOfMessage = textOfMessage;
    }

    public LocalDateTime getTimeOfSend() {
        return timeOfSend;
    }

    public void setTimeOfSend(LocalDateTime timeOfSend) {
        this.timeOfSend = timeOfSend;
    }

    public String getFromWho() {
        return fromWho;
    }

    public void setFromWho(String fromWho) {
        this.fromWho = fromWho;
    }

    public String getToWho() {
        return toWho;
    }

    public void setToWho(String toWho) {
        this.toWho = toWho;
    }

    public String getTextOfMessage() {
        return textOfMessage;
    }

    public void setTextOfMessage(String textOfMessage) {
        this.textOfMessage = textOfMessage;
    }
}
