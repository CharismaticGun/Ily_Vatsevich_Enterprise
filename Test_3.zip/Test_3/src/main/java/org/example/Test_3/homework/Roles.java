package org.example.Test_3.homework;

public enum Roles {
    ADMIN,
    USER;
    public static Roles checkRole(String role) {
        for (Roles value : values()) {
            if (role.equalsIgnoreCase(value.name())) {
                return value;
            }
        }
        throw new IllegalArgumentException("Такой роли нет");
    }
}
