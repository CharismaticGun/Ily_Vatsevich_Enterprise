package org.example.Test_3.homework.dto;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Objects;

public class User {

    private String login;

    private char[] password;

    private String firstSecondLastName;

    private String dateOfBirth;

    private LocalDate dateOfRegistration;

    private String role;

    public User(){}

    public User(String login, char[] password, String firstSecondLastName, String dateOfBirth, LocalDate dateOfRegistration, String role) {
        this.login = login;
        this.password = password;
        this.firstSecondLastName = firstSecondLastName;
        this.dateOfBirth = dateOfBirth;
        this.dateOfRegistration = dateOfRegistration;
        this.role = role;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public char[] getPassword() {
        return password;
    }

    public void setPassword(char[] password) {
        this.password = password;
    }

    public String getFirstSecondLastName() {
        return firstSecondLastName;
    }

    public void setFirstSecondLastName(String firstSecondLastName) {
        this.firstSecondLastName = firstSecondLastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public LocalDate getDateOfRegistration() {
        return dateOfRegistration;
    }

    public void setDateOfRegistration(LocalDate dateOfRegistration) {
        this.dateOfRegistration = dateOfRegistration;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(login, user.login) && Arrays.equals(password, user.password) && Objects.equals(firstSecondLastName, user.firstSecondLastName) && Objects.equals(dateOfBirth, user.dateOfBirth) && Objects.equals(dateOfRegistration, user.dateOfRegistration) && Objects.equals(role, user.role);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(login, firstSecondLastName, dateOfBirth, dateOfRegistration, role);
        result = 31 * result + Arrays.hashCode(password);
        return result;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        sb.append(login).append(";").
                append(password).
                append(";").
                append(firstSecondLastName).
                append(";").
                append(dateOfBirth).
                append(";").
                append(role).
                append(";").
                append(dateOfRegistration);

        return sb.toString();
    }
}
