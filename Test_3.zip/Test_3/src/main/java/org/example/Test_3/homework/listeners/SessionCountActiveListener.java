package org.example.Test_3.homework.listeners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import java.util.HashMap;
import java.util.Map;

@WebListener(value = "count")
public class SessionCountActiveListener implements HttpSessionAttributeListener {

    private Map<String,Integer> map = new HashMap<>();

    @Override
    public void attributeAdded(HttpSessionBindingEvent event) {

    }

    @Override
    public void attributeRemoved(HttpSessionBindingEvent event) {
        /**
         * TODO
         */
    }

    @Override
    public void attributeReplaced(HttpSessionBindingEvent event) {

    }
}
