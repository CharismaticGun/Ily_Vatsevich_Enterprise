package org.example.Test_3.homework.service;

import org.example.Test_3.homework.dto.Message;
import org.example.Test_3.homework.dto.User;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import java.util.List;

public class MessageControl {

    private final List<Message> messageList = new ArrayList<>();

    public void sendMessage(HttpServletRequest request,String login, String text) {
        Message message = new Message();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        message.setToWhom(login);
        message.setText(text);
        message.setSendTime(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
        message.setFromWhom(user.getFirstSecondLastName());
        messageList.add(message);
    }
    public List<Message> getMessage() {
        return messageList;
    }


}
