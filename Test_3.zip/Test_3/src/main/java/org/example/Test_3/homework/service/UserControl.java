package org.example.Test_3.homework.service;

import org.example.Test_3.homework.Roles;
import org.example.Test_3.homework.dto.User;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Locale;
public class UserControl {

    private static int counter = 0;

    private static final String COOKIE_USER = "user";

    public void userRegistration(HttpServletResponse resp, HttpServletRequest req, User user) throws UnsupportedEncodingException {

        Cookie[] cookies = req.getCookies();

        if (null == cookies) {
            User admin = new User("admin"
                ,"admin".toCharArray(),
                "Ivan jovanovich Ivanov",
                "18.09.1990",
                LocalDate.now().minusYears(5),
                Roles.ADMIN.name());
            resp.addCookie(new Cookie("admin",URLEncoder.encode(admin.toString(), StandardCharsets.UTF_8)));
            user.setRole(Roles.USER.name().toLowerCase(Locale.ROOT));
            user.setDateOfRegistration(LocalDate.now());
            resp.addCookie(new Cookie(COOKIE_USER + (++counter),URLEncoder.encode(user.toString(), StandardCharsets.UTF_8)));
            return;
        }
        user.setRole(Roles.USER.name().toLowerCase(Locale.ROOT));
        user.setDateOfRegistration(LocalDate.now());
            for (Cookie cookie : cookies) {
                if (cookie.getValue().equals(URLEncoder.encode(user.toString(),StandardCharsets.UTF_8))) {
                    throw new IllegalArgumentException("Такой пользователь уже есть");
                }
            }
        resp.addCookie(new Cookie(COOKIE_USER + (++counter),URLEncoder.encode(user.toString(),StandardCharsets.UTF_8)));
    }

    public User saveInSession(HttpServletRequest request,String login,String password) {

        User user  = new User();

        Cookie[] cookies = request.getCookies();

        out:
        for (Cookie cookie : cookies) {
            String value = URLDecoder.decode(cookie.getValue(),StandardCharsets.UTF_8);
            String[] s1 = value.split(";");
            for (int i = 0; i < s1.length; i++) {
                if (i == 0) {
                    user.setLogin(s1[i]);
                    if (!user.getLogin().equals(login)) {
                        continue out;
                    }
                } else if (i == 1) {
                    user.setPassword(s1[i].toCharArray());
                    if (!Arrays.equals(user.getPassword(), password.toCharArray())) {
                        continue out;
                    }
                } else if (i==2) {
                    user.setFirstSecondLastName(s1[i]);
                } else if (i==3) {
                    user.setDateOfBirth(s1[i]);
                } else if (i == 4) {
                    user.setRole(s1[i]);
                } else if (i == 5) {
                    user.setDateOfRegistration(LocalDate.parse(s1[i]));
                    return user;
                }
            }
        }
        throw new IllegalArgumentException("Пароль либо логин неверные");
    }
}
