package org.example.Test_3.homework.servlets;

import org.example.Test_3.homework.dto.User;
import org.example.Test_3.homework.service.UserControl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@WebServlet(name = "UserLoginServlet", urlPatterns = "/api/login")
public class UserLoginServlet extends HttpServlet {
    UserControl uc = new UserControl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        response.setContentType("text/html;charset=UTF-8");

        String login = request.getParameter("login");

        String password = request.getParameter("password");


        try {
            User value = uc.saveInSession(request, login, password);
            request.getSession().setAttribute("user",value);
        } catch (Exception e) {
            response.sendError(400,e.getMessage());
        }
    }
}
