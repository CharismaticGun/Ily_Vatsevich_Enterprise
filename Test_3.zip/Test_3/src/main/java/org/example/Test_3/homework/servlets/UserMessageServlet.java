package org.example.Test_3.homework.servlets;

import org.example.Test_3.homework.dto.Message;
import org.example.Test_3.homework.dto.User;
import org.example.Test_3.homework.service.MessageControl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@WebServlet(name = "UserMessageServlet", urlPatterns = "/api/message")
public class UserMessageServlet extends HttpServlet {

    private MessageControl control = new MessageControl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        resp.setContentType("text/html; charset=UTF-8");

        PrintWriter writer = resp.getWriter();

        HttpSession session = req.getSession();

        User user = (User) session.getAttribute("user");

        List<Message> message = control.getMessage();

        for (Message message1 : message) {
            if (message1.getToWhom().equals(user.getLogin())) {
                writer.write("<p>"+message1+"</br></p>");
            }
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String login = req.getParameter("login");

        String text = req.getParameter("text");

        control.sendMessage(req,login,text);

    }
}
