package org.example.Test_3.homework.servlets;

import org.example.Test_3.homework.dto.User;
import org.example.Test_3.homework.service.UserControl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UserRegistrationServlet",urlPatterns = "/api/user")
public class UserRegistrationServlet extends HttpServlet {

    private final UserControl uc = new UserControl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String login = req.getParameter("login");

        String password = req.getParameter("password");

        String fullName = req.getParameter("fullName");

        String dateOfBirth = req.getParameter("dateOfBirth");

        User user = new User();

        user.setLogin(login);
        user.setPassword(password.toCharArray());
        user.setFirstSecondLastName(fullName);
        user.setDateOfBirth(dateOfBirth);
        uc.userRegistration(resp,req,user);
    }
}
