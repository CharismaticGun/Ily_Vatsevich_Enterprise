package org.example.Test_3.home_work_with_out_cookie.service;

import org.example.Test_3.home_work_with_out_cookie.api.service.UserStorage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class UserStorageTest {

    UserStorage storage = UserStorage.getInstance();

    @Test
    void userRegistration() {
        Assertions.assertTrue(storage.userRegistration("s","","",""));
    }


}
