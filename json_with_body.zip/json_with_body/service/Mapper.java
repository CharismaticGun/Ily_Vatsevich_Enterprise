package org.example.JD2_Maven.json_with_body.service;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Mapper {

    private final ObjectMapper mapper;

    private Mapper() {
        mapper = new ObjectMapper();
    }

    private static final class MapperHolder {
        private static final Mapper mapperHolder = new Mapper();
    }

    public static Mapper getInstance() {
        return MapperHolder.mapperHolder;
    }

    public ObjectMapper getMapper() {
        return mapper;
    }
}

