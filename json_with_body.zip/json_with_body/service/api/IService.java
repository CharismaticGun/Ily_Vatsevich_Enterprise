package org.example.JD2_Maven.json_with_body.service.api;

import java.io.InputStream;
import java.util.List;

public interface IService<T> {

    <K extends InputStream> T createObjectFromJson(K input);

    String jsonFromListOfObjects(List<T> listOfObjects);

}
