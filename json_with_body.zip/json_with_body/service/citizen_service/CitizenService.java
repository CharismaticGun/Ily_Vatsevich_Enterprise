package org.example.JD2_Maven.json_with_body.service.citizen_service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import org.example.JD2_Maven.json_with_body.dto.Citizen;
import org.example.JD2_Maven.json_with_body.service.Mapper;
import org.example.JD2_Maven.json_with_body.service.api.IService;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CitizenService implements IService<Citizen> {

    private final Mapper mapper;

    public CitizenService() {
        mapper = Mapper.getInstance();
        mapper.getMapper().registerModule(
                new JavaTimeModule().addSerializer(
                        new LocalDateSerializer(DateTimeFormatter.ISO_LOCAL_DATE)));
        mapper.getMapper().setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }

    @Override
    public <T extends InputStream> Citizen createObjectFromJson(T input) {

        Citizen citizen;

        try {
            citizen = mapper.getMapper().readValue(input,Citizen.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return citizen;
    }

    @Override
    public String jsonFromListOfObjects(List<Citizen> listOfObjects) {

        try {
            return mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(listOfObjects);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private LocalDateTime formatDate(LocalDate date) {
        return date.atStartOfDay();
    }

   /* @Override
    public String jsonFromListOfObjects(List<Citizen> listOfObjects) {

        StringBuilder s  = new StringBuilder();

        Duration duration;

        for (Citizen citizen : listOfObjects) {
            duration = Duration.between(formatDate(LocalDate.EPOCH),formatDate(citizen.getPassport().getCreateDate()));
            try {
                s.append("{\"id\":").append(mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(citizen.getId()));
                s.append(",\"name\":").append(mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(citizen.getName()));
                s.append(",\"birthday\":").append(mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(citizen.getBirthday()));
                s.append(",\"passport\": {\"id_citizen\":").append(mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(citizen.getPassport().getIdCitizen()));
                s.append(",\"id\":").append(mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(citizen.getPassport().getId()));
                s.append(",\"address\":").append(mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(citizen.getPassport().getAddress()));
                s.append(",\"create_date\":").append(mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(duration.toDays())).append("}}");
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        }
        return s.toString();
    } */
}
