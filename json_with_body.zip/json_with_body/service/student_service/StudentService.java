package org.example.JD2_Maven.json_with_body.service.student_service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.InjectableValues;
import org.example.JD2_Maven.json_with_body.dto.Student;
import org.example.JD2_Maven.json_with_body.service.Mapper;
import org.example.JD2_Maven.json_with_body.service.api.IService;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class StudentService implements IService<Student> {

    private final Mapper mapper;

    private static int id = 1;

    public StudentService() {
        this.mapper = Mapper.getInstance();
    }

    public <T extends InputStream> Student createObjectFromJson(T input)  {

        InjectableValues injectId = new InjectableValues.Std().addValue(int.class,id++);

        Student student;

        try {
            student = mapper.getMapper().reader(injectId).readValue(input,Student.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return student;
    }

    public String jsonFromListOfObjects(List<Student> listOfObjects)  {

        try {
            return mapper.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(listOfObjects);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
