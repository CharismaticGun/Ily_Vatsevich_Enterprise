package org.example.JD2_Maven.json_with_body.servlets;

import org.example.JD2_Maven.json_with_body.dto.Citizen;
import org.example.JD2_Maven.json_with_body.service.api.IService;
import org.example.JD2_Maven.json_with_body.service.api.IStorage;
import org.example.JD2_Maven.json_with_body.service.citizen_service.CitizenService;
import org.example.JD2_Maven.json_with_body.service.citizen_service.CitizenStorage;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletCitizens", value = "/citizens")
public class ServletCitizens extends HttpServlet {

    private final IStorage<Citizen> storage;

    private final IService<Citizen> service;

    public ServletCitizens() {
        this.storage = CitizenStorage.getInstance();
        this.service = new CitizenService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {

        response.setContentType("json/application;charset=UTF-8");

        PrintWriter writer;

        try {
            writer = response.getWriter();
            writer.write(service.jsonFromListOfObjects(storage.getListOfObject()));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {

        try {
            storage.getListOfObject().add(service.createObjectFromJson(request.getInputStream()));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
