package org.example.JD2_Maven.json_with_body.servlets;

import org.example.JD2_Maven.json_with_body.dto.Student;
import org.example.JD2_Maven.json_with_body.service.api.IService;
import org.example.JD2_Maven.json_with_body.service.student_service.StudentService;
import org.example.JD2_Maven.json_with_body.service.api.IStorage;
import org.example.JD2_Maven.json_with_body.service.student_service.StudentStorage;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletStudents", value = "/students")
public class ServletStudents extends HttpServlet {
    private final IStorage<Student> storage;

    private final IService<Student> service;

    public ServletStudents() {
        this.storage = StudentStorage.getInstance();
        service = new StudentService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {

        response.setContentType("json/application;charset=UTF-8");

        PrintWriter writer;

        try{
            writer = response.getWriter();
            writer.write(service.jsonFromListOfObjects(storage.getListOfObject()));
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {

        try {
            storage.getListOfObject().add(service.createObjectFromJson(request.getInputStream()));
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
