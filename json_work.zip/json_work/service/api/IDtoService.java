package org.example.JD2_Maven.json_work.service.api;

import java.util.List;

public interface IDtoService<T> {

    T createObjectFromJson(String jsonString);

    String jsonFromListOfObjects(List<T> listOfObjects);
}
