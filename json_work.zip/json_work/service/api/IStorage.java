package org.example.JD2_Maven.json_work.service.api;

import java.util.List;

public interface IStorage<T> {

    List<T> getListOfObject();

}
