package org.example.JD2_Maven.json_work.service.citizen_service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.example.JD2_Maven.json_work.dto.Citizen;
import org.example.JD2_Maven.json_work.service.api.IDtoService;

import java.io.IOException;
import java.util.List;

public class CitizenService implements IDtoService<Citizen> {

    private final ObjectMapper mapper;

    public CitizenService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public Citizen createObjectFromJson(String jsonString) {

        mapper.registerModule(new JavaTimeModule());

        Citizen citizen;

        try {
            citizen = mapper.readValue(jsonString,Citizen.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return citizen;
    }

    @Override
    public String jsonFromListOfObjects(List<Citizen> listOfObjects) {

        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(listOfObjects);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
