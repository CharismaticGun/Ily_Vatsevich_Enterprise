package org.example.JD2_Maven.json_work.service.citizen_service;

import com.fasterxml.jackson.annotation.JsonRootName;
import org.example.JD2_Maven.json_work.dto.Citizen;
import org.example.JD2_Maven.json_work.service.api.IStorage;

import java.util.ArrayList;
import java.util.List;

public class CitizenStorage implements IStorage<Citizen> {

    private final List<Citizen> studentsStorage;

    private CitizenStorage(List<Citizen> studentsStorage) {
        this.studentsStorage = studentsStorage;
    }

    private static final class StudentStorageHolder {
        private static final CitizenStorage storage = new CitizenStorage(new ArrayList<>());
    }

    public static CitizenStorage getInstance() {
        return StudentStorageHolder.storage;
    }

    @Override
    public List<Citizen> getListOfObject() {
        return studentsStorage;
    }

}
