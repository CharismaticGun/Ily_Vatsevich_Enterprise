package org.example.JD2_Maven.json_work.service.student_service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.InjectableValues;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.example.JD2_Maven.json_work.dto.Student;
import org.example.JD2_Maven.json_work.service.api.IDtoService;

import java.io.IOException;
import java.util.List;

public class StudentService implements IDtoService<Student> {

    private final ObjectMapper mapper;

    private static int id = 1;

    public StudentService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public Student createObjectFromJson(String jsonString) {

        InjectableValues injectId = new InjectableValues.Std().addValue(int.class,id++);

        Student student;

        try {
            student = mapper.reader(injectId).readValue(jsonString,Student.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return student;
    }

    @Override
    public String jsonFromListOfObjects(List<Student> listOfObjects) {

        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(listOfObjects);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
