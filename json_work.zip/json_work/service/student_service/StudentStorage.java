package org.example.JD2_Maven.json_work.service.student_service;

import com.fasterxml.jackson.annotation.JsonRootName;
import org.example.JD2_Maven.json_work.dto.Student;
import org.example.JD2_Maven.json_work.service.api.IStorage;

import java.util.ArrayList;
import java.util.List;
public class StudentStorage implements IStorage<Student> {

    private final List<Student> studentsStorage;

    private StudentStorage(List<Student> studentsStorage) {
        this.studentsStorage = studentsStorage;
    }

    private static final class StudentStorageHolder {
        private static final StudentStorage storage = new StudentStorage(new ArrayList<>());
    }

    public static StudentStorage getInstance() {
        return StudentStorageHolder.storage;
    }

    @Override
    public List<Student> getListOfObject() {
        return studentsStorage;
    }

}
