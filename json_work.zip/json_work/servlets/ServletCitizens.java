package org.example.JD2_Maven.json_work.servlets;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.JD2_Maven.json_work.dto.Citizen;
import org.example.JD2_Maven.json_work.dto.Passport;
import org.example.JD2_Maven.json_work.service.api.IDtoService;
import org.example.JD2_Maven.json_work.service.api.IStorage;
import org.example.JD2_Maven.json_work.service.citizen_service.CitizenService;
import org.example.JD2_Maven.json_work.service.citizen_service.CitizenStorage;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

@WebServlet(name = "ServletCitizens", value = "/citizens")
public class ServletCitizens extends HttpServlet {

    private final IDtoService<Citizen> service;

    private final IStorage<Citizen> storage;

    public ServletCitizens() {
        this.service = new CitizenService(new ObjectMapper());
        this.storage = CitizenStorage.getInstance();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("json/application;charset=UTF-8");

        PrintWriter writer = response.getWriter();

        writer.write(service.jsonFromListOfObjects(storage.getListOfObject()));

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String citizenId = request.getParameter("citizenId");

        String passportId = request.getParameter("passportId");

        String address = request.getParameter("address");

        LocalDate createDate = LocalDate.parse(request.getParameter("createDate"));

        String name = request.getParameter("name");

        LocalDate birthday = LocalDate.parse(request.getParameter("birthday"));

        Passport passport = new Passport(passportId,citizenId,address,createDate);

        String jsonString = "{\"id\":\""+passport.getIdCitizen() + "\"," +
                "\"passport\":{\"id_citizen\":\"" + passport.getIdCitizen() + "\"," +
                "\"id\":\"" +passport.getId() +"\"," +
                "\"address\":\"" +passport.getAddress() +"\"," +
                "\"create_date\":\""+passport.getCreateDate()+"\""+"}," +
                "\"name\":\"" + name + "\"," +
                "\"birthday\":\"" + birthday + "\"}";

        storage.getListOfObject().add(service.createObjectFromJson(jsonString));

    }
}
