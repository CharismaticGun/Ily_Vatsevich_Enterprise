package org.example.JD2_Maven.json_work.servlets;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.JD2_Maven.json_work.dto.Student;
import org.example.JD2_Maven.json_work.service.api.IDtoService;
import org.example.JD2_Maven.json_work.service.api.IStorage;
import org.example.JD2_Maven.json_work.service.student_service.StudentService;
import org.example.JD2_Maven.json_work.service.student_service.StudentStorage;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletStudents", value = "/students")
public class ServletStudents extends HttpServlet {

    private final IDtoService<Student> service;

    private final IStorage<Student> storage;

    public ServletStudents() {
        this.service = new StudentService(new ObjectMapper());
        this.storage = StudentStorage.getInstance();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("json/application;charset=UTF-8");

        PrintWriter writer = response.getWriter();

        writer.write(service.jsonFromListOfObjects(storage.getListOfObject()));

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");

        int age = Integer.parseInt(request.getParameter("age"));

        double score = Double.parseDouble(request.getParameter("score"));

        boolean olympicGamer = Boolean.parseBoolean(request.getParameter("olympicGamer"));

        String jsonString = "{\"name\":\""+name +
                "\",\"age\":\"" + age +
                "\",\"score\":\"" + score +
                "\",\"olympicGamer\":\"" + olympicGamer + "\"}";

        storage.getListOfObject().add(service.createObjectFromJson(jsonString));
    }
}
